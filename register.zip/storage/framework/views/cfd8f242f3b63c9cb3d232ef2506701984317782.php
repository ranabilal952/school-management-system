<?php $__env->startSection('title'); ?>
    class Add
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\school\resources\views/student/create.blade.php ENDPATH**/ ?>